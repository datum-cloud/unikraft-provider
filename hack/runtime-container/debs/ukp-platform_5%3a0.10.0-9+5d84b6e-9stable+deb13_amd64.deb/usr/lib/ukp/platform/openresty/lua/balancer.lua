local balancer = require 'ngx.balancer'

local service = ngx.ctx.service

balancer.set_current_peer(service.destination_addr, service.destination_port)
