local ukp_proxy = require 'ukp_proxy_ffi'

local result = ukp_proxy.lookup_internal(ngx.var.server_addr,
                                         tonumber(ngx.var.server_port), {})
if result == nil then
	ngx.eof()
	return ngx.exit(200)
end

ngx.var.ukp_request_id = result.id
ngx.ctx.service = result
