local ukp_proxy = require 'ukp_proxy_ffi'

ukp_proxy.exit()
