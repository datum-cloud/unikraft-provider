local ukp_proxy = require 'ukp_proxy_ffi'
local consts = require 'consts'

local service = ngx.ctx.service
if service ~= nil then
	ukp_proxy.upstream_notify(service)
end

local timings = ngx.ctx.timings or {}
if consts.server_timing_header then
	local header_time = ngx.var.upstream_header_time
	if header_time ~= nil and header_time ~= "" then
		local header_time = tonumber(header_time)
		-- In some cases, nginx produces multiple values for the
		-- header time. We just ignore those cases for now.
		if header_time ~= nil then
			table.insert(timings,
				     string.format("nginx_upstream_header_time;dur=%d",
				                   header_time * 1000))
		end
	end
end

if #timings > 0 then
	ngx.header[consts.server_timing_header_name] = timings
end

if consts.node_id_header then
	ngx.header[consts.node_id_header_name] = ukp_proxy.get_node_id()
end
if consts.instance_id_header and service ~= nil then
	ngx.header[consts.instance_id_header_name] = ukp_proxy.get_vm_uuid(service)
end
