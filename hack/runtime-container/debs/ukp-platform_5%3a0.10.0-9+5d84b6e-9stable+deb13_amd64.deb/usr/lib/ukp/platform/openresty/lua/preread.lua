local ukp_proxy = require 'ukp_proxy_ffi'

local result, err = ukp_proxy.lookup(ngx.var.ssl_server_name,
                                     tonumber(ngx.var.server_port), {})
if result == nil then
	ngx.eof()
	return ngx.exit(200)
end

ngx.var.ukp_request_id = result.id
ngx.ctx.service = result
