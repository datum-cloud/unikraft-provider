local ukp_proxy = require 'ukp_proxy_ffi'

local service = ngx.ctx.service
if service ~= nil then
	ukp_proxy.close(service)
end
