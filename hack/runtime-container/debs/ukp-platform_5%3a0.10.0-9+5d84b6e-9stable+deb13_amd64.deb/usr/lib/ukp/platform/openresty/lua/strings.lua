local M = {}

function M.endsWith(str, suffix)
	return #str >= #suffix and str:sub(-#suffix) == suffix
end

return M
