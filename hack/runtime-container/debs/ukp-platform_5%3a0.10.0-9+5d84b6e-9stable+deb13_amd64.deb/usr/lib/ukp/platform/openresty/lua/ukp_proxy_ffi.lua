local consts = require 'consts'
local band, bor, lshift = bit.band, bit.bor, bit.lshift
local ffi = require 'ffi'

local M = {
	node_id = nil,
}

local UUID_LEN = 36
local UUID_C_STR_LEN = UUID_LEN + 1

ffi.cdef [[
/** Proxy ffi error codes */
enum ukp_proxy_error {
	UKP_PROXY_SUCCESS,		/* Operation completed successfully */
	UKP_PROXY_FETCH_REQUIRED,	/* Lookup failed, needs fetch */
	UKP_PROXY_NO_SERVER_AVAILABLE,	/* No server in the group available */
	UKP_PROXY_NO_SERVICE,		/* Requested service does not exist */
	UKP_PROXY_NO_CERTIFICATE,	/* No certificate for this domain */
	UKP_PROXY_TIMEOUT,		/* Operation timeout */
	UKP_PROXY_INTERNAL_ERROR,	/* Internal server error */
	UKP_PROXY_IMAGE_FETCH_ERROR,	/* Image fetch failed */

	UKP_PROXY_ERROR_MAX
};

/** Proxy protocol */
enum ukp_proxy_protocol {
	UKP_PROXY_PROTOCOL_TCP,
	UKP_PROXY_PROTOCOL_UDP,
};

/**
 * Request level statistics
 *
 * Unused fields are set to zero. Timings are µs-precise durations relative to
 * the previous timing towards external consumers.
 */
struct ukp_proxy_request_statistics {
	uint64_t reserved;

	/** Time until service group has been fetched */
	uint64_t proxy_srvgrp_fetch_time_us;

	/** Time until an IPC request was sent (proxy -> ukpd) */
	uint64_t proxy_ipc_send_req_time_us;
	/** Time until IPC command has been received (proxy -> ukpd) */
	uint64_t ukpd_ipc_recv_time_us;

	/** Time until VM has been created */
	uint64_t ukpd_vm_create_time_us;
	/** Time until start prerequisites were fulfilled */
	uint64_t ukpd_vm_start_prereq_time_us;
	/** Time until the VMM process is about to be spawned */
	uint64_t ukpd_vmm_prestart_time_us;
	/** Time until entering VMM main() */
	uint64_t ukpd_vmm_start_time_us;
	/** Time until the image has been loaded in VMM */
	uint64_t ukpd_vmm_load_time_us;
	/** Time until the resume of vCPUs */
	uint64_t ukpd_vmm_ready_time_us;
	/** Time until the OS boot finished */
	uint64_t ukpd_vmm_boot_time_us;
	/** Time until first listen socket is opened */
	uint64_t ukpd_vmm_net_time_us;

	/** Time until VM wait has finished */
	uint64_t proxy_vm_wait_time_us;
	/** Time until request is forwarded to nginx for processing */
	uint64_t proxy_forward_time_us;
};

/** Proxy connection */
struct ukp_proxy_connection {
	/** ID of the connection */
	uint32_t id;
	/** IPv4 address of the destination */
	char destination_addr[16];
	/** Port of the destination */
	uint16_t destination_port;
	/** Use HTTPS redirect */
	uint8_t redirect;
	/** This is an ACME challenge */
	uint8_t acme;
	/** Cert UUID */
	char cert_uuid[37];
	/** Whether this is an HTTP request */
	uint8_t is_req;
};

/** Proxy certificate */
struct ukp_proxy_certificate {
	/** Id of the certificate */
	uint32_t id;
	/** Certificate chain */
	void *chain;
	/** Private key */
	void *pkey;
};

/** Callback for logging */
typedef void (*ukp_proxy_log_cb)(int lvl, const char *str, size_t len);

int ukp_proxy_init(void);
void ukp_proxy_exit(void);

enum ukp_proxy_error
ukp_proxy_lookup(const char *log_ctx, const char *dns, uint16_t port,
                 enum ukp_proxy_protocol protocol, const char *uri,
                 uint32_t src_ip, struct ukp_proxy_connection *conn);
enum ukp_proxy_error
ukp_proxy_fetch(const char *log_ctx, const char *dns, uint16_t port,
                enum ukp_proxy_protocol protocol, const char *uri,
                uint32_t src_ip, const char *srv_jit,
                struct ukp_proxy_request_statistics *stats,
                struct ukp_proxy_connection *conn);
void ukp_proxy_vm_uuid(uint32_t id, char *vm_uuid);
void ukp_proxy_node_id(char *node_id);
void ukp_proxy_upstream_notify(uint32_t id);
void ukp_proxy_close(uint32_t id);

enum ukp_proxy_error
ukp_proxy_lookup_cert(const char *dns, struct ukp_proxy_certificate *cert);
enum ukp_proxy_error
ukp_proxy_lookup_cert_by_id(uint32_t id, struct ukp_proxy_certificate *cert);
enum ukp_proxy_error
ukp_proxy_fetch_cert(const char *dns, struct ukp_proxy_certificate *cert);
void ukp_proxy_close_cert(uint32_t id);
]]
---@alias ukp_proxy_error integer

local ukp_proxy_connection_type = ffi.typeof('struct ukp_proxy_connection')
local ukp_proxy_certificate_type = ffi.typeof('struct ukp_proxy_certificate')
local ukp_proxy_request_statistics_type =
	ffi.typeof('struct ukp_proxy_request_statistics')
local ukp_proxy = ffi.load('./lib/libukp_openresty.so')

-- Export error codes
M.SUCCESS = ukp_proxy.UKP_PROXY_SUCCESS
M.ERROR_FETCH_REQUIRED = ukp_proxy.UKP_PROXY_FETCH_REQUIRED
M.ERROR_NO_SERVER_AVAILABLE = ukp_proxy.UKP_PROXY_NO_SERVER_AVAILABLE
M.ERROR_NO_SERVICE = ukp_proxy.UKP_PROXY_NO_SERVICE
M.ERROR_NO_CERTIFICATE = ukp_proxy.UKP_PROXY_NO_CERTIFICATE
M.ERROR_TIMEOUT = ukp_proxy.UKP_PROXY_TIMEOUT
M.ERROR_INTERNAL_ERROR = ukp_proxy.UKP_PROXY_INTERNAL_ERROR
M.ERROR_IMAGE_FETCH_ERROR = ukp_proxy.UKP_PROXY_IMAGE_FETCH_ERROR

-- Export protocol types
M.PROTOCOL_TCP = ukp_proxy.UKP_PROXY_PROTOCOL_TCP
M.PROTOCOL_UDP = ukp_proxy.UKP_PROXY_PROTOCOL_UDP

---@class (exact) proxy_connection
---@field id integer
---@field destination_addr string
---@field destination_port integer
---@field redirect boolean
---@field acme boolean
---@field cert_uuid string
---@field stats string?

---Convert an ukp error code to a human-readable error
---@param err number
---@return string
local function error_to_string(err)
	if err == ukp_proxy.UKP_PROXY_SUCCESS then
		return "success"
	elseif err == ukp_proxy.UKP_PROXY_FETCH_REQUIRED then
		return "fetch required"
	elseif err == ukp_proxy.UKP_PROXY_NO_SERVER_AVAILABLE then
		return "no server available"
	elseif err == ukp_proxy.UKP_PROXY_NO_SERVICE then
		return "no service"
	elseif err == ukp_proxy.UKP_PROXY_NO_CERTIFICATE then
		return "no certificate"
	elseif err == ukp_proxy.UKP_PROXY_INTERNAL_ERROR then
		return "internal error"
	elseif err == ukp_proxy.UKP_PROXY_TIMEOUT then
		return "operation timeout"
	elseif err == ukp_proxy.UKP_PROXY_IMAGE_FETCH_ERROR then
		return "image fetch error"
	end
	return "unknown error (" .. tostring(err) .. ")"
end

local LOG_LEVELS = {
	-- UKP_LOGL_DBG
	ngx.DEBUG,
	-- UKP_LOGL_INF
	ngx.NOTICE,
	-- UKP_LOGL_WRN
	ngx.WARN,
	-- UKP_LOGL_ERR
	ngx.ERR,
}

local function log_print(lvl, buf, len)
	text = ffi.string(buf, len)
	ngx.log(LOG_LEVELS[lvl + 1], text)
end

---Initialize the proxy interface for the current worker process
---@return ukp_proxy_error
function M.init()
	return ukp_proxy.ukp_proxy_init()
end

---Deinitialize the proxy interface for the current worker process
function M.exit()
	ukp_proxy.ukp_proxy_exit();
end

---@class (exact) LookupOpts
---@field srv_jit string?
---@field uri string?
---@field collect_stats boolean?
---@field ctx string?
---@field protocol integer?

---Execute a blocking function in a worker thread
---@param func string
---@param dns string
---@param port integer
---@param opts LookupOpts
---@return any?
local function run_worker(func, dns, port, opts)
	local ok, r1, r2, r3 = ngx.run_worker_thread(
		'ukp_wake_pool', 'ukp_proxy_ffi', func, dns, port, opts
	)
	if not ok then
		ngx.log(ngx.ERR, 'worker: ', r1)
		return
	end
	if not r1 then
		if r2 ~= nil then
			ngx.log(ngx.ERR, 'w/ukpd(', dns, ':', port, '): ', r2)
		end
		return nil, r3
	end
	return r2, r3
end

---Extract the connection info from a connection ctype
---@param conn any
---@param stats table?
---@return proxy_connection
local function extract_connection(conn, stats)
	local stats_str
	if stats ~= nil then
		local stats_strings = {}
		local function add_stat(name, value)
			if value == nil or value == 0 then
				return
			end
			table.insert(stats_strings,
				string.format('%s;dur=%d', name, value / 1000))
		end

		add_stat('proxy_srvgrp_fetch_time', stats.proxy_srvgrp_fetch_time_us)
		add_stat('proxy_ipc_send_req_time', stats.proxy_ipc_send_req_time_us)
		add_stat('ukpd_ipc_recv_time', stats.ukpd_ipc_recv_time_us)
		add_stat('ukpd_vm_create_time', stats.ukpd_vm_create_time_us)
		add_stat('ukpd_vm_start_prereq_time', stats.ukpd_vm_start_prereq_time_us)
		add_stat('ukpd_vmm_prestart_time', stats.ukpd_vmm_prestart_time_us)
		add_stat('ukpd_vmm_start_time', stats.ukpd_vmm_start_time_us)
		add_stat('ukpd_vmm_load_time', stats.ukpd_vmm_load_time_us)
		add_stat('ukpd_vmm_ready_time', stats.ukpd_vmm_ready_time_us)
		add_stat('ukpd_vmm_boot_time', stats.ukpd_vmm_boot_time_us)
		add_stat('ukpd_vmm_net_time', stats.ukpd_vmm_net_time_us)
		add_stat('proxy_vm_wait_time', stats.proxy_vm_wait_time_us)
		add_stat('proxy_forward_time', stats.proxy_forward_time_us)

		stats_str = table.concat(stats_strings, ", ")
	end
	return {
		id = conn.id,
		destination_addr = ffi.string(conn.destination_addr),
		destination_port = conn.destination_port,
		redirect = conn.redirect ~= 0,
		acme = conn.acme ~= 0,
		cert_uuid = ffi.string(conn.cert_uuid),
		is_req = conn.is_req ~= 0,
		stats = stats_str,
	}
end

---Get the IPv4 source address if it is from an internal source, or 0
---@return integer
local function get_internal_source_ip()
	local n_ip = ngx.var.binary_remote_addr
	if #n_ip ~= 4 then
		return 0
	end

	local w_ip = bor(lshift(string.byte(n_ip, 1), 24),
	                 lshift(string.byte(n_ip, 2), 16),
	                 lshift(string.byte(n_ip, 3), 8),
	                 string.byte(n_ip, 4))

	if band(w_ip, consts.proxy_net_segment.mask) ==
	   consts.proxy_net_segment.addr then
		return w_ip
	end

	return 0
end

---Lookup the specified dns+port combo
---@param dns string
---@param port integer
---@param opts LookupOpts
---@return any?
function M.lookup(dns, port, opts)
	local conn = ffi.new(ukp_proxy_connection_type)
	local res = ukp_proxy.ukp_proxy_lookup(opts.ctx, dns, port,
	                                       opts.protocol or M.PROTOCOL_TCP,
	                                       opts.uri, 0, conn)

	if res == ukp_proxy.UKP_PROXY_SUCCESS then
		return extract_connection(conn)
	elseif res == ukp_proxy.UKP_PROXY_FETCH_REQUIRED then
		return run_worker('do_fetch', dns, port, opts)
	else
		ngx.log(ngx.ERR, 'ukpd(', dns, ':', port, '): ',
		        error_to_string(res))
	end

	return nil, res
end

---Lookup the specified internal ip+port combo
---@param ip string
---@param port integer
---@param opts LookupOpts
---@return any?
function M.lookup_internal(ip, port, opts)
	local src_ip = get_internal_source_ip()
	if src_ip == 0 then
		return nil
	end
	opts.internal_src_ip = src_ip

	local conn = ffi.new(ukp_proxy_connection_type)
	local res = ukp_proxy.ukp_proxy_lookup(
		opts.ctx, ip, port, opts.protocol or M.PROTOCOL_TCP, opts.uri,
		src_ip, conn)

	if res == ukp_proxy.UKP_PROXY_SUCCESS then
		return extract_connection(conn)
	elseif res == ukp_proxy.UKP_PROXY_FETCH_REQUIRED then
		return run_worker('do_fetch', ip, port, opts)
	else
		ngx.log(ngx.ERR, 'ukpd(', ip, ':', port, '): ',
		        error_to_string(res))
	end

	return nil, res
end

---Fetch the service from ukp with blocking
---@param dns string
---@param port integer
---@param opts LookupOpts
---@return boolean, proxy_connection | string
function M.do_fetch(dns, port, opts)
	local conn = ffi.new(ukp_proxy_connection_type)
	local stats = nil
	if opts.collect_stats then
		stats = ffi.new(ukp_proxy_request_statistics_type)
	end

	local res = ukp_proxy.ukp_proxy_fetch(
		opts.ctx, dns, port, opts.protocol or M.PROTOCOL_TCP, opts.uri,
		opts.internal_src_ip or 0, opts.srv_jit, stats, conn)

	if res == ukp_proxy.UKP_PROXY_SUCCESS then
		return true, extract_connection(conn, stats), nil
	else
		return false, error_to_string(res), tonumber(res)
	end
end

---Notify ukp_openresty about upstream data
---@param conn proxy_connection
function M.upstream_notify(conn)
	ukp_proxy.ukp_proxy_upstream_notify(conn.id)
end

---Close the connection
---@param conn proxy_connection
function M.close(conn)
	ukp_proxy.ukp_proxy_close(conn.id)
end

---Extract the certificate info from a certificate ctype
---@param cert any
---@return proxy_certificate
local function extract_certificate(cert)
	return {
		id    = cert.id,
		chain = cert.chain,
		pkey  = cert.pkey,
	}
end

---Lookup the certificate for the specified dns name
---@param dns string
---@return proxy_certificate?
function M.lookup_cert(dns)
	local cert = ffi.new(ukp_proxy_certificate_type)
	local res = ukp_proxy.ukp_proxy_lookup_cert(dns, cert)
	if res == ukp_proxy.UKP_PROXY_SUCCESS then
		return extract_certificate(cert)
	elseif res == ukp_proxy.UKP_PROXY_FETCH_REQUIRED then
		local id = run_worker('do_fetch_cert', dns, -1, nil)
		if id ~= nil then
			res = ukp_proxy.ukp_proxy_lookup_cert_by_id(id, cert)
			if res == ukp_proxy.UKP_PROXY_SUCCESS then
				return extract_certificate(cert)
			end

			ngx.log(ngx.ERR, 'ukpd(', dns, '): Failed to lookup \z
			                  cert ID: ', error_to_string(res))
		end
	elseif res == ukp_proxy.UKP_PROXY_INTERNAL_ERROR then
		-- NO_CERTIFICATE and NO_SERVICE should not throw an error
		-- So only internal error possible for certificate request
		ngx.log(ngx.ERR, 'ukpd(', dns, '): ', error_to_string(res))
	end

	return nil
end

---Fetch the certificate from ukp with blocking
---@param dns string
---@return boolean, integer | string?
function M.do_fetch_cert(dns)
	local cert = ffi.new(ukp_proxy_certificate_type)
	local res = ukp_proxy.ukp_proxy_fetch_cert(dns, cert)
	if res == ukp_proxy.UKP_PROXY_SUCCESS then
		return true, cert.id
	elseif res == ukp_proxy.UKP_PROXY_INTERNAL_ERROR then
		-- NO_CERTIFICATE and NO_SERVICE should not throw an error
		-- So only internal error possible for certificate request
		return false, error_to_string(res)
	end

	return false, nil
end

---Close the certificate
---@param cert proxy_certificate
function M.close_cert(cert)
	ukp_proxy.ukp_proxy_close_cert(cert.id)
end

---Retrieve the used instance UUID of a connection
---@param conn proxy_connection
function M.get_vm_uuid(conn)
	if conn == nil then
		return nil
	end

	local uuid_c_str = ffi.new("char[?]", UUID_C_STR_LEN)
	ukp_proxy.ukp_proxy_vm_uuid(conn.id, uuid_c_str)
	return ffi.string(uuid_c_str)
end

---Fetch the node id from ukp
---@return string
function M.get_node_id()
	if M.node_id ~= nil then
		return M.node_id
	end

	local node_id_c_str = ffi.new("char[?]", UUID_C_STR_LEN)
	ukp_proxy.ukp_proxy_node_id(node_id_c_str)

	M.node_id = ffi.string(node_id_c_str)
	return M.node_id
end

return M
