local ukp_proxy = require 'ukp_proxy_ffi'

local function ipv4_to_inaddr(ip, port)
	local a,b,c,d = ip:match("^(%d+)%.(%d+)%.(%d+)%.(%d+)$")
	if not a then return nil end
	return string.format("%d.udp.%s.%s.%s.%s.in-addr.arpa", port, d, c, b, a)
end

local dns = ipv4_to_inaddr(ngx.var.server_addr, tonumber(ngx.var.server_port))
if dns == nil then
	ngx.log(ngx.ERR, 'Failed to parse IP address')
	ngx.eof()
	return ngx.exit(200)
end
local result, err = ukp_proxy.lookup(dns, tonumber(ngx.var.server_port), {
	protocol = ukp_proxy.PROTOCOL_UDP
})
if result == nil then
	return ngx.exit(200)
end

ngx.var.ukp_request_id = result.id
ngx.ctx.service = result
