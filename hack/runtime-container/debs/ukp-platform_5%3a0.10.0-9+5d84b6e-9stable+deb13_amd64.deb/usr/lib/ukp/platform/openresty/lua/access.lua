local ukp_proxy = require 'ukp_proxy_ffi'
local consts = require 'consts'
local strings = require 'strings'

local request_uri = ngx.var.request_uri
local server_port = tonumber(ngx.var.server_port)
local host

if server_port == 80 then
	host = ngx.var.host
else
	host = ngx.var.ssl_server_name or ngx.var.host
end

if host == nil or host == consts.proxy_host or consts.is_host_ip(host) then
	return ngx.exec('@api_domain')
end

local ukp_srv = ngx.var.http_ukp_srv
if ukp_srv == '' then
	-- Remap a non-existent header to nil
	ukp_srv = nil
end

local result, err = ukp_proxy.lookup(host, server_port, {
	uri = request_uri,
	srv_jit = ukp_srv,
	collect_stats = consts.server_timing_header,
})
if result == nil then
	return ngx.exit(404)
elseif result.redirect then
	return ngx.redirect('https://' .. host .. request_uri)
elseif result.acme then
	return ngx.exec('/acme/' .. result.cert_uuid .. request_uri)
end

-- Setting it to `nil` would result in no header, but we do the check anyway
-- to avoid the expensive table lookup if possible
if result.stats ~= nil then
	local timings = ngx.ctx.timings or {}
	table.insert(timings, result.stats)
	ngx.ctx.timings = timings
end

ngx.ctx.service = result
