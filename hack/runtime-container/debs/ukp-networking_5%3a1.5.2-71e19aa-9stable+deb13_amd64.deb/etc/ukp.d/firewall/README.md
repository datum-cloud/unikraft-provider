# UKP Firewall Customization

To support customization of `iptable` rules installed by the UKP firewall, the
`ukp-firewall.service` scans for executables (typically, scripts with the
executable bit set) in two hook directories: `early.d/` and `late.d/`.

- Executables in `early.d/` are run *before* the main firewall rules are
  installed. This allows you to define custom `iptable` rules that take
  precedence.
- Executables in `late.d/` are run *after* the main rules are applied, enabling
  you to append additional logic as needed.

This structure provides flexibility to tailor firewall behavior to your specific
requirements.


## Hook Calling

The hooks are invoked whenever the `ukp-firewall.service` is started or
reloaded. On each run, the `iptable` chains (`INPUT`, `OUTPUT`, `FORWARD`, and
`NAT` tables) are cleared and can be assumed empty. However, the contents of
`ipset`s persist between runs—they are **not** reset during a reload. `ipset`s
are only flushed when the service is stopped or restarted (which triggers both
`stop` and then `start` actions).

This behavior exists because `ukp-vnet.service` populates these `ipset`s with
customer network information. To allow independent reloads of
`ukp-firewall.service` without disrupting, the `ipset` entries are preserved. In
contrast, if `ukp-firewall.service` is restarted, `systemd` will automatically
restart `ukp-vnet.service`, ensuring a full reset of both services.

The following environment variables are provided for a hook execution:

- `$HAVE_IP6`:
  `"y"` if IPv6 support is enabled, `"n"` if IPv6 support is disabled.
  Note that IPv6 is only provided on the public-facing interface, the internal
  virtual customer networks are IPv4 only.
- `$ADDR4_IFACE`:
  Public-facing IPv4 address.
- `$ADDR6_IFACE`:
  Public-facing IPv6 address (empty if `HAVE_IP6` is `"n"`).
- `$NET_IFACE_OUTBOUND`:
  Interface name for outbound traffic, recommended to use this for
  iptable rules.
- `$NET_IFACE`:
  Interface name containing public-facing IP address (typically identical to
  `$NET_IFACE_OUTBOUND`, except dummy interfaces are used).
- `$NET_SEGMENT`:
  Network segment (CIDR) from which customer subnets are allocated.
- `$NET_GW4_SET`:
  Name of ipset containing tuples of gateway addresses and iface of tenants
  (`hash:net,iface`).
- `$NET_NET4_SET`:
  Name of ipset containing tuples of networks and ifaces of tenants
  (`hash:net,iface`).
- `$NET_BLOCK4_SET`:
  Name of ipset with banned/blocked IPs (/32) and networks for tenants
  (`hash:net`).

Additionally, the hooks are called with the following arguments:
```
 ./hook $ACTION $NET_IFACE_OUTBOUND $ADDR4_IFACE $ADDR6_IFACE
```

**Note:**
> `$ACTION` is reserved for future use and currently only contains `start`.
> Scripts should check this value to ensure compatibility with future versions
> of the service.
