#!/usr/bin/python3
import re
import os
import sys
import math
import json
import argparse
import subprocess
from pyroute2 import IPRoute
from tqdm.contrib.concurrent import process_map

dryrun = False
debug = False
# Initialize interfaces serialized starting from the given number.
# `0` deaktivates this feature, `1` does serialized init for all interfaces
slowinit = 10000

# WARNING: Meaning of network numbering always depends on number of hostbits
#          Use sanity to check for overlapping networks
default_prefix   = 24
default_maxvifs  = 16
maxvifs_per_vbr  = 510
script_vif    = os.path.realpath("../scripts/setup-vifnet")

def div_round_up(a, b):
	return int(math.ceil(a / b))

def div_round_down(a, b):
	return int(math.floor(a / b))

# UKP network
class ukpnet:
	def __init__(self, netid=0, prefix=30, maxvifs=1, netclass=1):
		if netclass == 1:
			# = 172.16.0.0/12 ===
			self._raw_net4   = int(172 << 8+8+8)
			self._raw_net4  += int(16  << 8+8)
			reserved_netbits = 12
		elif netclass == 2:
			## = 192.168.0.0/16 ===
			self._raw_net4   = int(192 << 8+8+8)
			self._raw_net4  += int(168 << 8+8)
			reserved_netbits = 16
		else: # netclass == 0
			## = 10.0.0.0/8 ===
			self._raw_net4   = int(10 << 8+8+8)
			reserved_netbits = 8
			netclass         = 0

		# We subtract 1 from reserved bits since we use the upper half
		# of the network for srvgrp addresses
		reserved_netbits -= 1

		if prefix < reserved_netbits:
			raise Exception("prefix too small (min: {} for class {})".format(reserved_netbits, netclass))
		if prefix > 30:
			raise Exception("prefix too large (max: {})".format(30))

		hostbits = 32 - int(prefix)
		avail_netbits = 32 - reserved_netbits - hostbits
		if 2 ** (avail_netbits) <= netid:
			raise Exception("netid ({}) too large for available netbits network (max: {})".format(netid, (2 ** avail_netbits) - 1))

		# generate the net address as 32bit integer
		self._raw_net4 += int(netid << hostbits)
		self._hostbits  = hostbits
		self._netbits   = int(prefix)
		self._netid     = int(netid)
		self._maxvifs   = maxvifs
		# reserve one for root bridge connection
		self._vifs_per_vbr = maxvifs_per_vbr - 1;

	def _cidr4_tuple(self, raw_ip4):
		ip4p0 = int((raw_ip4 / (256*256*256)))
		ip4p1 = int((raw_ip4 / (256*256)) % 256)
		ip4p2 = int((raw_ip4 / (256)) % 256)
		ip4p3 = int( raw_ip4 % 256)
		return (ip4p0, ip4p1, ip4p2, ip4p3, self._netbits)

	def _hwaddr_tuple(self, raw_hwaddr):
		hwaddrp0 = int((raw_hwaddr / (256*256*256*256*256)))
		hwaddrp1 = int((raw_hwaddr / (256*256*256*256)) % 256)
		hwaddrp2 = int((raw_hwaddr / (256*256*256)) % 256)
		hwaddrp3 = int((raw_hwaddr / (256*256)) % 256)
		hwaddrp4 = int((raw_hwaddr / (256)) % 256)
		hwaddrp5 = int( raw_hwaddr % 256)
		return (hwaddrp0, hwaddrp1, hwaddrp2, hwaddrp3, hwaddrp4, hwaddrp5)

	def _cidr4_str(self, cidr4_tuple):
		return "{}.{}.{}.{}/{}".format(cidr4_tuple[0], cidr4_tuple[1], cidr4_tuple[2], cidr4_tuple[3], cidr4_tuple[4])

	def _ip4host_str(self, cidr4_tuple):
		return "{}.{}.{}.{}".format(cidr4_tuple[0], cidr4_tuple[1], cidr4_tuple[2], cidr4_tuple[3])

	def _hwaddr_str(self, hwaddr_tuple):
		return "{0:02x}:{1:02x}:{2:02x}:{3:02x}:{4:02x}:{5:02x}".format(
			hwaddr_tuple[0], hwaddr_tuple[1], hwaddr_tuple[2],
			hwaddr_tuple[3], hwaddr_tuple[4], hwaddr_tuple[5])

	def __str__(self):
		return self.str4net()

	def cidr4net(self):
		return self._cidr4_tuple(self._raw_net4)

	def _cidr4host(self, hostid):
		if (2 ** self._netbits) <= hostid:
			raise Exception("hostid too large for network (max: {})".format((2 ** self._hostbits) - 1))
		return self._cidr4_tuple(self._raw_net4 + hostid)

	def _hwaddrhost(self, hostid):
		# Local MAC addresses, for virtual devices
		# x2:xx:xx:xx:xx:xx
		# x6:xx:xx:xx:xx:xx
		# xA:xx:xx:xx:xx:xx
		# xE:xx:xx:xx:xx:xx
		if (2 ** self._netbits) <= hostid:
			raise Exception("hostid too large for network (max: {})".format((2 ** self._hostbits) - 1))
		return self._hwaddr_tuple((0x12 << (5*8)) + (0xB0 << (4*8)) + self._raw_net4 + hostid)

	def cidr4vif(self, vifid):
		if ((2 ** self._netbits) - 1) <= vifid:
			raise Exception("vifid too large for network (max: {})".format((2 ** self._hostbits) - 2))
		if 0 >= vifid:
			raise Exception("vifid too small for network (min: {})".format(1))
		return self._cidr4host(vifid)
	def str4vif(self, vifid):
		return self._ip4host_str(self.cidr4vif(vifid))

	def cidr4net(self):
		return self._cidr4host(0)
	def str4net(self):
		return "{}/{}".format(self._ip4host_str(self.cidr4net()), self._netbits)
	def str4mask(self):
		raw_mask4 = ((2 ** 32) - 1) - ((2 ** self._hostbits) - 1)
		return self._ip4host_str(self._cidr4_tuple(raw_mask4))

	def cidr4broadcast(self):
		return self._cidr4host((2 ** self._hostbits) - 1)
	def str4broadcast(self):
		return self._ip4host_str(self.cidr4broadcast())

	def cidr4gw(self):
		return self._cidr4host((2 ** self._hostbits) - 2)
	def str4gw(self):
		return self._ip4host_str(self.cidr4gw())

	def vif_max(self):
		return (2 ** self._hostbits) - 3
	def vif_count(self):
		return min(self._maxvifs, self.vif_max())
	def vifids(self):
		return range(1, self.vif_count() + 1)
	def vifids_unused(self):
		return range(self.vif_count() + 1, self.vif_max())

	def net4bits(self):
		return self._netbits

	def vbr_name(self, vifid=-1): # -1 is root bridge if exists
		if vifid < 0 or not self.vbr_isstar():
			return "ukp{}.vbr".format(self._netid) # root bridge
		return self.subvbr_name(div_round_down(vifid, self._vifs_per_vbr))

	# returns a list of subbridges needed to handle vif_max() interfaces (star topology)
	# For non-star-topologies, this list is empty
	def subvbrids(self):
		subvbrs = [ ]
		if self.vbr_isstar():
			subvbrs = range(0, self.subvbr_count())
		return subvbrs
	def subvbr_count(self):
		if self.vbr_isstar():
			return div_round_down(self.vif_max(), self._vifs_per_vbr)
		else:
			return 0
	def subvbr_name(self, subvbr_id):
		return "ukp{}.vbr{}".format(self._netid, subvbr_id)

	def subvbr_names(self):
		subvbrs = [ ]
		if self.vbr_isstar():
			for i in self.subvbrids():
				subvbrs.append(self.subvbr_name(i))
		return subvbrs

	# Returns True if number of vifs require a star topology of bridges
	def vbr_isstar(self):
		if self.vif_max() > self._vifs_per_vbr:
			return True
		return False

	def netid(self):
		return self._netid

	def gw_hwaddr(self):
		return self._hwaddr_str(self._hwaddrhost((2 ** self._hostbits) - 2))

	def vif_name(self, vifid):
		if ((2 ** self._netbits) - 1) <= vifid:
			raise Exception("vifid too large for network (max: {})".format((2 ** self._hostbits) - 2))
		if 0 >= vifid:
			raise Exception("vifid too small for network (min: {})".format(1))
		return "ukp{}.vif{}".format(self._netid, int(vifid))

	def vif_hwaddr(self, vifid):
		if ((2 ** self._netbits) - 1) <= vifid:
			raise Exception("vifid too large for network (max: {})".format((2 ** self._hostbits) - 2))
		if 0 >= vifid:
			raise Exception("vifid too small for network (min: {})".format(1))
		return self._hwaddr_str(self._hwaddrhost(vifid))

	# Checks if a UKPNet collides with another UKPNet
	def collides(self, net2):
		if type(net2) != type(self):
			raise TypeError("Argument must be of type 'ukpnet'")

		self_base  = self._raw_net4
		self_len   = (2 ** self._hostbits)
		net2_base  = net2._raw_net4
		net2_len   = (2 ** net2._hostbits)

		if self_base + self_len > net2_base and \
		   net2_base + net2_len > self_base:
			return True

		return False

	def isequal(self, net2):
		if type(net2) != type(self):
			raise TypeError("Argument must be of type 'ukpnet'")

		if self._raw_net4 == net2._raw_net4 and \
		   self._hostbits == net2._hostbits:
			return True
		return False

# Returns a dictionary of networks: {netid: (<vbr name>, {<vifid: <vif name>, ...}), ...}
# If <vbr name> is None, a bridge does not exist but vifs
# In case of mininets, <vbr name> is empty and only one vif with id 1 exists
def scan_nets():
	vbrpatt = re.compile(r'ukp(\d+)\.vbr') # 1=netid
	vifpatt = re.compile(r'ukp(\d+).vif(\d+)') # 1=netid, 2=vifid

	# NOTE: On a huge number of interfaces, specifying
	#       the kind during the query fails so we query for all
	#       interfaces and sort them afterwards
	ipr = IPRoute()
	links = ipr.get_links()
	ipr.close()

	nets = {}
	for link in links:
		name = link.get_attr('IFLA_IFNAME')
		if not name:
			continue # ignore invalid interface

		m = vifpatt.match(name)
		if m:
			# device is a vif
			netid = int(m.group(1))
			vifid = int(m.group(2))

			if netid in nets:
				# entry already exists
				nets[netid][1][vifid] = name
			else:
				# entry does not yet exist: create
				nets[netid] = (None, {vifid: name})
			continue

		m = vbrpatt.match(name)
		if m:
			# device is a bridge
			netid = int(m.group(1))

			if netid in nets:
				# entry already exists, set name
				nets[netid] = (name, nets[netid][1])
			else:
				# entry does not yet exist: create
				nets[netid] = (name, {})
			continue
	return nets

def scan_is_mininet(net):
	if net == None:
		return False

	# 1: bridge name must be None
	# 2: only one vif exists
	# 3: vif has id 1
	# 4: TODO: Check network segment size
	if net[0] == None and \
	   len(net[1]) == 1 and \
	   1 in net[1]:
		return True
	return False

def op_info_mininet(netclass=0, num_nets=4096):
	for netid in range(num_nets):
		net = ukpnet(netid, 30, 1, netclass)

		print("Network {}:".format(net.netid()))
		print("\tNetwork:         {} (mask: {})".format(net.str4net(), net.str4mask()))
		print("\tGateway:         {} / {}".format(net.str4gw(), net.gw_hwaddr()))
		print("\tGuest:           {} / {}".format(net.str4vif(1), net.vif_hwaddr(1)))
		print("\tBroadcast:       {}".format(net.str4broadcast()))
		print("\tInterface:       {}".format(net.vif_name(1)))
	return 0

def _op_vif_mininet(args):
	op, netclass, netid = args

	net = ukpnet(netid, 30, 1, netclass) # 4 IPs, allowing network IP and broadcast IP
	if debug:
		print("net{}: {} vif1".format(net.netid(), op))
	if not dryrun:
		subprocess.check_call([script_vif, op, net.vif_name(1),
				       net.str4gw(), net.gw_hwaddr(),
				       net.str4vif(1), net.str4net(), net.vif_hwaddr(1)])

def op_reload_mininet(netclass=0, num_nets=4096, force_add=False):
	if slowinit == 0:
		# Fast-init only
		process_map(_op_vif_mininet, [("add", netclass, netid) for netid in range(num_nets)], desc="Creating vifs", chunksize=64, ascii=True, unit="vifs")
	else:
		# Phase 1: Fast-init
		process_map(_op_vif_mininet, [("add", netclass, netid) for netid in range(min(num_nets, slowinit))], desc="Creating vifs", chunksize=64, ascii=True, unit="vifs")

		# Phase 2: Slow-init
		if slowinit < num_nets:
			print("Creating vif{} to vif{} serialized. This may take a while...".format(slowinit, (num_nets - 1)))
			for netid in range(slowinit, num_nets):
				_op_vif_mininet(("add", netclass, netid))
	return 0

def op_start_mininet(netclass=0, num_nets=4096):
	return op_reload_mininet(netclass, num_nets, True)

def op_stop_mininet(netclass=0, num_nets=4096):
	process_map(_op_vif_mininet, [("del", netclass, netid) for netid in range(num_nets)], desc="Removing vifs", chunksize=64, ascii=True, unit="vifs")
	return 0

def op_repair_mininet(netclass=0, num_nets=4096, force_add=False):
	print("Scanning for existing networks, this may take a while...", flush=True)
	scanned = scan_nets()
	print("Detected {} networks that were already created.".format(len(scanned)))

	print("Repairing networks...", flush=True)
	for netid in range(0, num_nets):
		if scanned and netid in scanned:
			enet = scanned[netid] # the entwork already exists
			del scanned[netid]

			if not scan_is_mininet(enet):
				print("FATAL: Detected network {} is not an 'isolates' network, skipping repair... Did you change from 'subnets' to 'isolates'?".format(netid))
				continue

			# refresh network
			_op_vif_mininet(("add", netclass, netid))

		else:
			# create missing network
			_op_vif_mininet(("add", netclass, netid))

	# Delete any extra net that is not covered by the user file
	print("Deleting overprovisioned networks...", flush=True)
	if scanned:
		for netid in scanned:
			enet = scanned[netid] # the entwork already exists
			if not scan_is_mininet(enet):
				print("FATAL: Detected network {} is not an 'isolates' network, skipping deletion... Did you change from 'subnets' to 'isolates'?".format(netid))
				continue

			# remove extra network
			_op_vif_mininet(("del", netclass, netid))
	return 0

def segcidr2netclass(cidr4):
	if cidr4 == "192.168.0.0/16":
		return 2
	elif cidr4 == "172.16.0.0/12":
		return 1
	elif cidr4 == "10.0.0.0/8":
		return 0

	raise Exception("'{}' is not a class A, B, or C network in CIDR notation".format(cidr4))

##
## MAIN
##
if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='Unikraft Platform NETIF Tool (Mininet version)')
	parser.add_argument("op", choices=['info', 'start', 'stop', 'restart', 'reload', 'repair'],
			    help="Type of operation to perform")
	parser.add_argument("segment_cidr4",
			    help="CIDR (IPv4) notation of private network segment (must be class A, B, or C)")
	parser.add_argument("num_mininets",
			    help="Number of isolated mini networks")
	opt, rem_args = parser.parse_known_args()

	arg_netclass = segcidr2netclass(opt.segment_cidr4)
	arg_num_mininets = int(opt.num_mininets)

	if opt.op == 'info':
		ret = op_info_mininet(arg_netclass, arg_num_mininets)
	elif opt.op == 'start':
		ret = op_start_mininet(arg_netclass, arg_num_mininets)
	elif opt.op == 'reload':
		ret = op_reload_mininet(arg_netclass, arg_num_mininets)
	elif opt.op == 'stop':
		ret = op_stop_mininet(arg_netclass, arg_num_mininets)
	elif opt.op == 'restart':
		ret = op_stop_mininet(arg_netclass, arg_num_mininets)
		if ret == 0:
			ret = op_start(arg_netclass, arg_num_mininets)
	elif opt.op == 'repair':
		ret = op_repair_mininet(arg_netclass, arg_num_mininets)
	sys.exit(ret)
