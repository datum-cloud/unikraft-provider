#!/usr/bin/python3
import re
import os
import sys
import json
import argparse
import traceback
import subprocess
from pyroute2 import IPRoute
from tqdm.contrib.concurrent import process_map

dryrun = False
debug = False

# WARNING: In order to avoid network overlaps, the number of hostbits must currently match for every customer
default_prefix   = 24
default_maxvifs  = 16
maxvifs_per_vbr  = 510
script_vbr    = os.path.realpath("../scripts/setup-vbrnet")
script_vif    = os.path.realpath("../scripts/setup-vbrnet-vif")

# UKP network
class ukpnet:
	def __init__(self, netid=0, prefix=30, maxvifs=1, netclass=1):
		if netclass == 1:
			# = 172.16.0.0/12 ===
			self._raw_net4   = int(172 << 8+8+8)
			self._raw_net4  += int(16  << 8+8)
			reserved_netbits = 12
		elif netclass == 2:
			## = 192.168.0.0/16 ===
			self._raw_net4   = int(192 << 8+8+8)
			self._raw_net4  += int(168 << 8+8)
			reserved_netbits = 16
		else: # netclass == 0
			## = 10.0.0.0/8 ===
			self._raw_net4   = int(10 << 8+8+8)
			reserved_netbits = 8
			netclass         = 0

		if prefix < reserved_netbits:
			raise Exception("prefix too small (min: {} for class {})".format(reserved_netbits, netclass))
		if prefix > 30:
			raise Exception("prefix too large (max: {})".format(30))

		hostbits = 32 - int(prefix)
		avail_netbits = 32 - reserved_netbits - hostbits
		if 2 ** (avail_netbits) <= netid:
			raise Exception("netid ({}) too large for available netbits network (max: {})".format(netid, (2 ** avail_netbits) - 1))

		# generate the net address as 32bit integer
		self._raw_net4 += int(netid << hostbits)
		self._hostbits  = hostbits
		self._netbits   = int(prefix)
		self._netid     = int(netid)
		self._maxvifs   = maxvifs
		# reserve one for root bridge connection
		self._vifs_per_vbr = maxvifs_per_vbr - 1;

	def _cidr4_tuple(self, raw_ip4):
		ip4p0 = int((raw_ip4 / (256*256*256)))
		ip4p1 = int((raw_ip4 / (256*256)) % 256)
		ip4p2 = int((raw_ip4 / (256)) % 256)
		ip4p3 = int( raw_ip4 % 256)
		return (ip4p0, ip4p1, ip4p2, ip4p3, self._netbits)

	def _hwaddr_tuple(self, raw_hwaddr):
		hwaddrp0 = int((raw_hwaddr / (256*256*256*256*256)))
		hwaddrp1 = int((raw_hwaddr / (256*256*256*256)) % 256)
		hwaddrp2 = int((raw_hwaddr / (256*256*256)) % 256)
		hwaddrp3 = int((raw_hwaddr / (256*256)) % 256)
		hwaddrp4 = int((raw_hwaddr / (256)) % 256)
		hwaddrp5 = int( raw_hwaddr % 256)
		return (hwaddrp0, hwaddrp1, hwaddrp2, hwaddrp3, hwaddrp4, hwaddrp5)

	def _cidr4_str(self, cidr4_tuple):
		return "{}.{}.{}.{}/{}".format(cidr4_tuple[0], cidr4_tuple[1], cidr4_tuple[2], cidr4_tuple[3], cidr4_tuple[4])

	def _ip4host_str(self, cidr4_tuple):
		return "{}.{}.{}.{}".format(cidr4_tuple[0], cidr4_tuple[1], cidr4_tuple[2], cidr4_tuple[3])

	def _hwaddr_str(self, hwaddr_tuple):
		return "{0:02x}:{1:02x}:{2:02x}:{3:02x}:{4:02x}:{5:02x}".format(
			hwaddr_tuple[0], hwaddr_tuple[1], hwaddr_tuple[2],
			hwaddr_tuple[3], hwaddr_tuple[4], hwaddr_tuple[5])

	def __str__(self):
		return self.str4net()

	def cidr4net(self):
		return self._cidr4_tuple(self._raw_net4)

	def _cidr4host(self, hostid):
		if (2 ** self._netbits) <= hostid:
			raise Exception("hostid too large for network (max: {})".format((2 ** self._hostbits) - 1))
		return self._cidr4_tuple(self._raw_net4 + hostid)

	def _hwaddrhost(self, hostid):
		# Local MAC addresses, for virtual devices
		# x2:xx:xx:xx:xx:xx
		# x6:xx:xx:xx:xx:xx
		# xA:xx:xx:xx:xx:xx
		# xE:xx:xx:xx:xx:xx
		if (2 ** self._netbits) <= hostid:
			raise Exception("hostid too large for network (max: {})".format((2 ** self._hostbits) - 1))
		return self._hwaddr_tuple((0x12 << (5*8)) + (0xB0 << (4*8)) + self._raw_net4 + hostid)

	def cidr4vif(self, vifid):
		if ((2 ** self._netbits) - 1) <= vifid:
			raise Exception("vifid too large for network (max: {})".format((2 ** self._hostbits) - 2))
		if 0 >= vifid:
			raise Exception("vifid too small for network (min: {})".format(1))
		return self._cidr4host(vifid)
	def str4vif(self, vifid):
		return self._ip4host_str(self.cidr4vif(vifid))

	def cidr4net(self):
		return self._cidr4host(0)
	def str4net(self):
		return "{}/{}".format(self._ip4host_str(self.cidr4net()), self._netbits)
	def str4mask(self):
		raw_mask4 = ((2 ** 32) - 1) - ((2 ** self._hostbits) - 1)
		return self._ip4host_str(self._cidr4_tuple(raw_mask4))

	def cidr4broadcast(self):
		return self._cidr4host((2 ** self._hostbits) - 1)
	def str4broadcast(self):
		return self._ip4host_str(self.cidr4broadcast())

	def cidr4gw(self):
		return self._cidr4host((2 ** self._hostbits) - 2)
	def str4gw(self):
		return self._ip4host_str(self.cidr4gw())

	def vif_max(self):
		return (2 ** self._hostbits) - 3
	def vif_count(self):
		return min(self._maxvifs, self.vif_max())
	def vifids(self):
		return range(1, self.vif_count() + 1)
	def vifids_unused(self):
		return range(self.vif_count() + 1, self.vif_max())

	def net4bits(self):
		return self._netbits

	def vbr_name(self, vifid=-1): # -1 is root bridge if exists
		if vifid < 0 or not self.vbr_isstar():
			return "ukp{}.vbr".format(self._netid) # root bridge
		return self.subvbr_name(div_round_down(vifid, self._vifs_per_vbr))

	# returns a list of subbridges needed to handle vif_max() interfaces (star topology)
	# For non-star-topologies, this list is empty
	def subvbrids(self):
		subvbrs = [ ]
		if self.vbr_isstar():
			subvbrs = range(0, self.subvbr_count())
		return subvbrs
	def subvbr_count(self):
		if self.vbr_isstar():
			return div_round_down(self.vif_max(), self._vifs_per_vbr)
		else:
			return 0
	def subvbr_name(self, subvbr_id):
		return "ukp{}.vbr{}".format(self._netid, subvbr_id)

	def subvbr_names(self):
		subvbrs = [ ]
		if self.vbr_isstar():
			for i in self.subvbrids():
				subvbrs.append(self.subvbr_name(i))
		return subvbrs

	# Returns True if number of vifs require a star topology of bridges
	def vbr_isstar(self):
		if self.vif_max() > self._vifs_per_vbr:
			return True
		return False

	def netid(self):
		return self._netid

	def gw_hwaddr(self):
		return self._hwaddr_str(self._hwaddrhost((2 ** self._hostbits) - 2))

	def vif_name(self, vifid):
		if ((2 ** self._netbits) - 1) <= vifid:
			raise Exception("vifid too large for network (max: {})".format((2 ** self._hostbits) - 2))
		if 0 >= vifid:
			raise Exception("vifid too small for network (min: {})".format(1))
		return "ukp{}.vif{}".format(self._netid, int(vifid))

	def vif_hwaddr(self, vifid):
		if ((2 ** self._netbits) - 1) <= vifid:
			raise Exception("vifid too large for network (max: {})".format((2 ** self._hostbits) - 2))
		if 0 >= vifid:
			raise Exception("vifid too small for network (min: {})".format(1))
		return self._hwaddr_str(self._hwaddrhost(vifid))

	# Checks if a UKPNet collides with another UKPNet
	def collides(self, net2):
		if type(net2) != type(self):
			raise TypeError("Argument must be of type 'ukpnet'")

		self_base  = self._raw_net4
		self_len   = (2 ** self._hostbits)
		net2_base  = net2._raw_net4
		net2_len   = (2 ** net2._hostbits)

		if self_base + self_len > net2_base and \
		   net2_base + net2_len > self_base:
			return True

		return False

	def isequal(self, net2):
		if type(net2) != type(self):
			raise TypeError("Argument must be of type 'ukpnet'")

		if self._raw_net4 == net2._raw_net4 and \
		   self._hostbits == net2._hostbits:
			return True
		return False

# Returns a dictionary of networks: {netid: (<vbr name>, {<vifid: <vif name>, ...}), ...}
# If <vbr name> is None, a bridge does not exist but vifs
def scan_nets():
	vbrpatt = re.compile(r'ukp(\d+)\.vbr') # 1=netid
	vifpatt = re.compile(r'ukp(\d+).vif(\d+)') # 1=netid, 2=vifid

	# NOTE: On a huge number of interfaces, specifying
	#       the kind during the query fails so we query for all
	#       interfaces and sort them afterwards
	ipr = IPRoute()
	links = ipr.get_links()
	ipr.close()

	nets = {}
	for link in links:
		name = link.get_attr('IFLA_IFNAME')
		if not name:
			continue # ignore invalid interface

		m = vifpatt.match(name)
		if m:
			# device is a vif
			netid = int(m.group(1))
			vifid = int(m.group(2))

			if netid in nets:
				# entry already exists
				nets[netid][1][vifid] = name
			else:
				# entry does not yet exist: create
				nets[netid] = (None, {vifid: name})
			continue

		m = vbrpatt.match(name)
		if m:
			# device is a bridge
			netid = int(m.group(1))

			if netid in nets:
				# entry already exists, set name
				nets[netid] = (name, nets[netid][1])
			else:
				# entry does not yet exist: create
				nets[netid] = (name, {})
			continue
	return nets

def op_info(userdb, netclass=0):
	for user in userdb:
		try:
			uuid  = user['uuid']
			name  = user['name']
			netid = user['network_id']
		except:
			print("Skipping incomplete user data (user: {})".format(user))
			continue

		net = ukpnet(netid, default_prefix, default_maxvifs, netclass)
		print("Customer {} ({}):".format(uuid, name))
		print("\tNetwork ID:      {}".format(netid))
		print("\tNetwork:         {} (mask: {})".format(net.str4net(), net.str4mask()))
		print("\tGateway:         {}".format(net.str4gw()))
		print("\tAvailable vifs:  {}".format(net.vif_max()))
		print("\tAllocated vifs:  {}".format(net.vif_count()))
		print("\tBridge name:     {}".format(net.vbr_name()))
	return 0

def _op_vbr(args):
	op, net = args
	if debug:
		print("net{}: {} vbr{}".format(net.netid(), op, net.netid(), op))
	if not dryrun:
		subprocess.check_call([script_vbr, op, net.vbr_name(), net.str4net(), "{}/{}".format(net.str4gw(), net.net4bits()), net.gw_hwaddr()])

def _op_vif(args):
	op, net, vifid = args
	if debug:
		print("net{}: {} vif{}.{}".format(net.netid(), op, net.netid(), vifid, op))
	if not dryrun:
		subprocess.check_call([script_vif, op, net.vbr_name(), net.vif_name(vifid), net.str4vif(vifid), net.vif_hwaddr(vifid)])

def _get_nvifs(user):
	return user.get("vmdb", {}).get("max_instances", default_maxvifs)

def op_reload(userdb, netclass=0, force_add=False):
	scanned = scan_nets()

	for user in userdb:
		try:
			uuid  = user['uuid']
			name  = user['name']
			netid = user['network_id']
			nvifs = _get_nvifs(user)
		except:
			print("Skipping incomplete user data (user: {})".format(user))
			continue

		net = ukpnet(netid, default_prefix, nvifs, netclass)
		enet = None
		if scanned and netid in scanned:
			enet = scanned[netid] # the entwork already exists

		# Create bridge
		if force_add or not enet or not enet[0]:
			_op_vbr(("add", net))

		if force_add:
			process_map(_op_vif, [("add", net, vifid) for vifid in net.vifids()], chunksize=20, desc="Creating vifs for {} ({})".format(name, uuid), ascii=True, unit='vifs')
		else:
			# Create vifs (if they do not exist yet)
			process_map(_op_vif, [("add", net, vifid) for vifid in net.vifids() if not enet or not enet[1] or vifid not in enet[1]], chunksize=20, desc="Creating vifs for {} ({})".format(name, uuid), ascii=True, unit='vifs')

		# Remove any extra vif
		if enet and enet[1]:
			process_map(_op_vif, [("del", net, vifid) for vifid in range(net.vif_count() + 1, max(enet[1]) + 1) if vifid in enet[1]], chunksize=20, desc="Deleting overprovisioned vifs for {} ({})".format(name, uuid), ascii=True, unit='vifs')

		# remove handled network from scanned
		if enet:
			del scanned[netid]

	# Delete any extra net that is not covered by the user file
	if scanned:
		for netid in scanned:
			enet = scanned[netid]
			net = ukpnet(netid, default_prefix, default_maxvifs, netclass)
			if enet[1]:
				process_map(_op_vif, [("del", net, vifid) for vifid in enet[1]], chunksize=20, desc="Deleting vifs of unassigned netid {}".format(netid), ascii=True, unit='vifs')
			if enet[0]:
				_op_vbr(("del", net))

	return 0

def op_start(userdb, netclass=0):
	return op_reload(userdb, netclass, force_add=True)

def op_stop(netclass=0):
	scanned = scan_nets()

	if scanned:
		for netid in scanned:
			enet = scanned[netid]
			net = ukpnet(netid, default_prefix, default_maxvifs, netclass)
			if enet[1]:
				process_map(_op_vif, [("del", net, vifid) for vifid in enet[1]], chunksize=20, desc="Deleting vifs of netid {}".format(netid), ascii=True, unit='vifs')
			if enet[0]:
				_op_vbr(("del", net))
	return 0

def segcidr2netclass(cidr4):
	if cidr4 == "192.168.0.0/16":
		return 2
	elif cidr4 == "172.16.0.0/12":
		return 1
	elif cidr4 == "10.0.0.0/8":
		return 0

	raise Exception("'{}' is not a class A, B, or C network in CIDR notation".format(cidr4))

##
## MAIN
##
if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='Unikraft Platform NETIF Tool')
	parser.add_argument("op", choices=['info', 'start', 'stop', 'restart', 'reload'],
			    help="Type of operation to perform")
	parser.add_argument("segment_cidr4",
			    help="CIDR (IPv4) notation of private network segment (must be class A, B, or C)")
	parser.add_argument("userdb",
			    help="User database to load (JSON format)")
	opt, rem_args = parser.parse_known_args()

	arg_netclass = segcidr2netclass(opt.segment_cidr4)

	try:
		with open(opt.userdb) as f:
			userdb = json.load(f)
	except:
		print("Failed to load user database {}".format(opt.userdb))
		print(traceback.format_exc())
		sys.exit(1)

	if opt.op == 'info':
		ret = op_info(userdb, arg_netclass)
	elif opt.op == 'start':
		ret = op_start(userdb, arg_netclass)
	elif opt.op == 'reload':
		ret = op_reload(userdb, arg_netclass)
	elif opt.op == 'stop':
		ret = op_stop(arg_netclass)
	elif opt.op == 'restart':
		ret = op_stop(arg_netclass)
		if ret == 0:
			ret = op_start(userdb, arg_netclass)
	sys.exit(ret)
